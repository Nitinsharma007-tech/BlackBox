from pydantic import BaseModel


class LoginRequest(BaseModel):

    email: str
    password: str


class LoginResponse(BaseModel):

    token: str
    user: dict
    profile: dict | None = None